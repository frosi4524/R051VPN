
#!/bin/bash
clear
echo "🛠️ Menginstall SKT Backup..."

# Ekstrak file
unzip -o skt-backup-package.zip -d / >/dev/null 2>&1

# Ubah permission
chmod +x /usr/bin/skt-backup
chmod +x /usr/bin/skt-restore

# Buat folder config jika belum ada
mkdir -p /etc/skt

# Cek konfigurasi
if [ ! -f /etc/skt/token.conf ]; then
  echo "TOKEN=isi_token_bot_anda" > /etc/skt/token.conf
  echo "ID=isi_chat_id_anda" >> /etc/skt/token.conf
  echo "📝 Silakan edit /etc/skt/token.conf dan isi dengan TOKEN serta ID Telegram Anda."
else
  echo "✅ Config /etc/skt/token.conf sudah ada."
fi

echo "✅ Installasi selesai. Jalankan perintah: skt-backup"
